# ESP32 LED integration — planned stage

The current Flask prototype exposes:

`GET http://<COMPUTER-IP>:5000/api/slots`

It returns JSON similar to:

```json
[
  {"slot_id":"A1","status":"Available","distance_order":1},
  {"slot_id":"A2","status":"Reserved","distance_order":2},
  {"slot_id":"A3","status":"Occupied","distance_order":3}
]
```

An ESP32 integration can read this endpoint over the same Wi-Fi network and control one indicator LED per slot. This is documentation only; the ESP32 firmware is not included yet because the board model, LED wiring and network details have not been confirmed.

Do not connect LEDs directly without suitable current-limiting resistors. Confirm the board pinout and wiring before powering the circuit.
