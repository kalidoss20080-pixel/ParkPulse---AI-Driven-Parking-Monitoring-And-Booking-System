# Smart Parking Management System

## Project Description

A web-based prototype developed to display parking slot availability, guide drivers to the nearest available slot, and allow drivers to reserve parking spaces. An operator dashboard is provided to update slot status.

## Technologies Used

Python, Flask, SQLite, HTML, CSS and JavaScript.

## Features

- View parking slot availability.
- Display the nearest available parking slot.
- Book an available slot using a vehicle number.
- Automatically expire a demo reservation after 10 minutes if it is not marked as arrived.
- View and update slot status through the operator dashboard.
- Preview the parking area using a connected webcam.

## What I Learned

Python web application development, Flask routing, database handling with SQLite, HTML form processing, JavaScript webcam access, debugging and project organisation.

## How to Run

1. Install Python 3.10 or newer.
2. Open the project folder in VS Code.
3. Create and activate a virtual environment:

   ```bash
   py -m venv .venv
   .venv\\Scripts\\activate
   ```

4. Install the required package:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Start the application:

   ```bash
   python app.py
   ```

6. Open `http://127.0.0.1:5000` in your browser.

   - Driver dashboard: `/`
   - Operator dashboard: `/operator`

## Project Contribution

This is the initial software prototype for the **Beyond Boundaries** team project. The current version includes the web dashboards, booking workflow, SQLite storage and webcam preview.

## Current Scope

The webcam is currently used for live preview only; automatic vehicle detection is not yet implemented. ESP32-controlled slot indicator LEDs and automatic number-plate recognition (ANPR) are planned extensions and are not included in this version.
